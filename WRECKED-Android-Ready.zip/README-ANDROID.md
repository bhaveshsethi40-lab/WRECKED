# WRECKED — Android build

This project packages the supplied Vite/React game as an Android app using Capacitor.

## Build on GitHub from an Android phone

1. Create a GitHub repository named `wrecked-android`.
2. Upload all files in this folder, including `.github/workflows/build-apk.yml`.
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build WRECKED APK** and tap **Run workflow**.
6. When the workflow finishes, open the workflow run and download the `WRECKED-debug-apk` artifact.
7. Extract the downloaded artifact and install `app-debug.apk` on Android.

The APK is a debug/sideload build. It is suitable for installing and testing on your phone. A Play Store release needs a signed release build with a private keystore.
