import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.bhavesh.wrecked',
  appName: 'WRECKED',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#000000'
  }
};

export default config;
