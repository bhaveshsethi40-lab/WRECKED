import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Play, Pause, RotateCcw, Home, Volume2, VolumeX, Trophy, Zap,
  ChevronUp, ChevronDown, Heart, Coins, Gauge, Crown, Timer,
  Wind, Sparkles, Keyboard, Hand, Medal, Skull,
} from 'lucide-react';
import { GameEngine, type GameResult, type HudSnapshot } from './game/engine';
import { sound } from './game/audio';
import { loadScores, saveScore, qualifies, lastName, saveName, type ScoreEntry } from './game/storage';

type Screen = 'menu' | 'playing' | 'paused' | 'gameover';

interface Banner { id: number; text: string; sub?: string; kind: 'info' | 'gold' | 'danger'; }

const fmt = (n: number) => n.toLocaleString('en-US');

export default function App() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [screen, setScreen] = useState<Screen>('menu');
  const screenRef = useRef<Screen>('menu');
  screenRef.current = screen;

  const [hud, setHud] = useState<HudSnapshot>({ score: 0, distance: 0, coins: 0, hearts: 3, maxHearts: 3, speedMps: 0, speedNorm: 0, combo: 0, multiplier: 1, best: 0, time: 0 });
  const [banner, setBanner] = useState<Banner | null>(null);
  const [result, setResult] = useState<GameResult | null>(null);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [best, setBest] = useState(() => (loadScores()[0]?.score ?? 0));
  const [isBest, setIsBest] = useState(false);
  const [muted, setMuted] = useState(sound.muted);
  const [name, setName] = useState(lastName());
  const [savedId, setSavedId] = useState<string | null>(null);
  const [canSave, setCanSave] = useState(false);
  const bannerId = useRef(0);
  const savedRef = useRef(false);
  const resultRef = useRef<GameResult | null>(null);
  const touchStart = useRef<{ y: number; id: number; slid: boolean } | null>(null);
  const [isTouch] = useState(() =>
    typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0 || window.matchMedia?.('(pointer: coarse)').matches));

  const showBanner = useCallback((text: string, sub?: string, kind: Banner['kind'] = 'info') => {
    const id = ++bannerId.current;
    setBanner({ id, text, sub, kind });
    window.setTimeout(() => {
      setBanner((b) => (b && b.id === id ? null : b));
    }, 1900);
  }, []);

  const persistScores = useCallback((list: ScoreEntry[]) => {
    setScores(list);
    setBest(list[0]?.score ?? 0);
    engineRef.current?.setBest(list[0]?.score ?? 0);
  }, []);

  const doSave = useCallback((res: GameResult, playerName: string) => {
    if (savedRef.current) return;
    savedRef.current = true;
    const clean = (playerName || 'ACE').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6) || 'ACE';
    saveName(clean);
    const list = saveScore({ name: clean, score: res.score, distance: res.distance, coins: res.coins, topSpeed: res.topSpeed });
    persistScores(list);
    const mine = list
      .filter((s) => s.score === res.score && s.name === clean)
      .sort((a, b) => b.date - a.date)[0];
    setSavedId(mine ? mine.id : null);
  }, [persistScores]);

  // ---------- engine lifecycle ----------
  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;

    const engine = new GameEngine(canvas, {
      onHud: (h) => setHud(h),
      onBanner: (t, s, k) => showBanner(t, s, k ?? 'info'),
      onGameOver: (r) => {
        resultRef.current = r;
        setResult(r);
        const prevBest = loadScores()[0]?.score ?? 0;
        const nb = r.score > prevBest && r.score > 0;
        setIsBest(nb);
        if (nb) {
          window.setTimeout(() => sound.newBest(), 350);
          showBanner('NEW BEST!', `${fmt(r.score)} pts`, 'gold');
        }
        const q = qualifies(r.score);
        savedRef.current = false;
        setSavedId(null);
        setCanSave(q);
        if (!q) {
          // not a high score: still refresh best display just in case
          persistScores(loadScores());
        }
        setScreen('gameover');
      },
      onDamage: () => {},
    }, best);
    engineRef.current = engine;

    const onResize = () => engine.resize();
    window.addEventListener('resize', onResize);
    window.addEventListener('orientationchange', onResize);
    const onVis = () => {
      if (document.hidden && screenRef.current === 'playing') {
        engine.pause();
        setScreen('paused');
      }
    };
    document.addEventListener('visibilitychange', onVis);
    // initial hud
    persistScores(loadScores());

    return () => {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('orientationchange', onResize);
      document.removeEventListener('visibilitychange', onVis);
      engine.destroy();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------- actions ----------
  const startGame = useCallback(() => {
    sound.unlock();
    sound.uiClick();
    savedRef.current = false;
    setSavedId(null);
    setResult(null);
    setIsBest(false);
    setScreen('playing');
    engineRef.current?.start();
    if (!sound.musicOn) sound.startMusic();
  }, []);

  const pauseGame = useCallback(() => {
    engineRef.current?.pause();
    setScreen('paused');
    sound.uiClick();
  }, []);

  const resumeGame = useCallback(() => {
    sound.unlock(); sound.uiClick();
    setScreen('playing');
    engineRef.current?.resume();
  }, []);

  const quitToMenu = useCallback(() => {
    // auto-save pending high score with last name
    if (screenRef.current === 'gameover' && resultRef.current && canSave && !savedRef.current) {
      doSave(resultRef.current, lastName());
    }
    sound.uiClick();
    engineRef.current?.toMenu();
    setScreen('menu');
    persistScores(loadScores());
  }, [canSave, doSave, persistScores]);

  const retry = useCallback(() => {
    if (screenRef.current === 'gameover' && resultRef.current && canSave && !savedRef.current) {
      doSave(resultRef.current, lastName());
    }
    startGame();
  }, [canSave, doSave, startGame]);

  const toggleMute = useCallback(() => {
    sound.unlock();
    const m = !sound.muted;
    sound.setMuted(m);
    setMuted(m);
  }, []);

  // ---------- keyboard ----------
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const eng = engineRef.current;
      if (!eng) return;
      const s = screenRef.current;
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        if (e.repeat) return;
        if (s === 'menu') { startGame(); return; }
        if (s === 'gameover') { retry(); return; }
        if (s === 'paused' && e.code === 'Space') { resumeGame(); return; }
        eng.jumpPress();
      } else if (e.code === 'ArrowDown' || e.code === 'KeyS') {
        e.preventDefault();
        if (e.repeat) return;
        if (s === 'playing') eng.slidePress();
      } else if (e.code === 'KeyP' || e.code === 'Escape') {
        if (s === 'playing') pauseGame();
        else if (s === 'paused') resumeGame();
      } else if (e.code === 'Enter') {
        if (s === 'menu') startGame();
        else if (s === 'gameover') retry();
        else if (s === 'paused') resumeGame();
      } else if (e.code === 'KeyR') {
        if (s === 'playing' || s === 'paused' || s === 'gameover') {
          if (s === 'gameover' && resultRef.current && canSave && !savedRef.current) doSave(resultRef.current, lastName());
          startGame();
        }
      } else if (e.code === 'KeyM') {
        toggleMute();
      }
    };
    const up = (e: KeyboardEvent) => {
      const eng = engineRef.current;
      if (!eng) return;
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') eng.jumpRelease();
      if (e.code === 'ArrowDown' || e.code === 'KeyS') eng.slideRelease();
    };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); };
  }, [startGame, retry, pauseGame, resumeGame, toggleMute, canSave, doSave]);

  // ---------- pointer (tap = jump, swipe down = slide) ----------
  const onPointerDown = (e: React.PointerEvent) => {
    if (screenRef.current !== 'playing') return;
    if ((e.target as HTMLElement).closest('[data-ui]')) return;
    sound.unlock();
    touchStart.current = { y: e.clientY, id: e.pointerId, slid: false };
    engineRef.current?.jumpPress();
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const t = touchStart.current;
    if (!t || e.pointerId !== t.id || screenRef.current !== 'playing') return;
    if (!t.slid && e.clientY - t.y > 44) {
      t.slid = true;
      engineRef.current?.slidePress();
    }
  };
  const onPointerUp = (e: React.PointerEvent) => {
    const t = touchStart.current;
    if (!t || e.pointerId !== t.id) return;
    engineRef.current?.jumpRelease();
    engineRef.current?.slideRelease();
    touchStart.current = null;
  };

  const speedPct = Math.round(hud.speedNorm * 100);
  const velocityLabel = hud.speedNorm < 0.25 ? 'WARM-UP' : hud.speedNorm < 0.55 ? 'CRUISING' : hud.speedNorm < 0.8 ? 'BLAZING' : 'LIGHTSPEED';

  return (
    <div
      className="scanlines vignette relative h-[100dvh] w-full overflow-hidden bg-[#070714]"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div ref={wrapRef} className="absolute inset-0">
        <canvas ref={canvasRef} className="game-canvas absolute inset-0" />
      </div>

      {/* ================= HUD ================= */}
      {(screen === 'playing' || screen === 'paused') && (
        <div className="pointer-events-none absolute inset-0 z-10" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
          {/* top bar */}
          <div className="flex items-start justify-between gap-2 px-3 pt-3 sm:px-5 sm:pt-4">
            <div className="anim-rise" data-ui>
              <div className="font-display text-[10px] tracking-[0.3em] text-cyan-300/80">SCORE</div>
              <div className="font-display tabular text-3xl font-800 font-extrabold text-white text-glow-cyan sm:text-4xl">{fmt(hud.score)}</div>
              <div className="mt-1 flex items-center gap-3 text-sm font-semibold">
                <span className="tabular text-fuchsia-200/90">{hud.distance}m</span>
                <span className="flex items-center gap-1 text-amber-300"><Coins className="h-3.5 w-3.5" /><span className="tabular">{hud.coins}</span></span>
                {hud.combo >= 3 && (
                  <span className="flex items-center gap-1 rounded-full border border-amber-300/40 bg-amber-400/10 px-2 py-0.5 text-[11px] font-bold text-amber-200">
                    <Sparkles className="h-3 w-3" />x{hud.multiplier.toFixed(1)} · {hud.combo}
                  </span>
                )}
              </div>
            </div>

            <div className="flex flex-col items-end gap-2" data-ui>
              <div className="pointer-events-auto flex items-center gap-2">
                <div className="mr-1 hidden items-center gap-1.5 rounded-full border border-white/10 bg-black/40 px-3 py-1.5 backdrop-blur-md sm:flex">
                  <Trophy className="h-3.5 w-3.5 text-amber-300" />
                  <span className="font-display tabular text-xs font-bold text-white/90">{fmt(Math.max(best, hud.score))}</span>
                </div>
                <button onClick={toggleMute} className="btn-ghost neon-btn pointer-events-auto flex h-9 w-9 items-center justify-center rounded-full text-white/80" aria-label="mute">
                  {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                </button>
                {screen === 'playing' && (
                  <button onClick={pauseGame} className="btn-ghost neon-btn pointer-events-auto flex h-9 w-9 items-center justify-center rounded-full text-white/80" aria-label="pause">
                    <Pause className="h-4 w-4" />
                  </button>
                )}
              </div>
              <div className="flex items-center gap-1.5">
                {Array.from({ length: hud.maxHearts }).map((_, i) => (
                  <Heart
                    key={i}
                    className={`h-4 w-4 transition-all ${i < hud.hearts ? 'fill-rose-500 text-rose-400 drop-shadow-[0_0_6px_rgba(244,63,94,0.9)]' : 'text-white/20'}`}
                  />
                ))}
              </div>
              <div className="flex items-center gap-1.5 rounded-full border border-cyan-300/25 bg-black/40 px-2.5 py-1 backdrop-blur-md">
                <Gauge className="h-3.5 w-3.5 text-cyan-300" />
                <span className="font-display tabular text-xs font-bold text-cyan-100">{hud.speedMps} m/s</span>
              </div>
            </div>
          </div>

          {/* velocity bar */}
          <div className="absolute left-1/2 top-3 hidden -translate-x-1/2 flex-col items-center sm:top-4 md:flex" style={{ marginTop: 'env(safe-area-inset-top)' }}>
            <div className="font-display text-[9px] tracking-[0.35em] text-white/50">{velocityLabel}</div>
            <div className="mt-1.5 flex w-56 items-center gap-2">
              <span className="font-display text-[9px] font-bold text-cyan-300">SLOW</span>
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full transition-[width] duration-300"
                  style={{ width: `${Math.max(4, speedPct)}%`, background: 'linear-gradient(90deg,#22d3ee,#8b5cf6,#ff2d95)', boxShadow: '0 0 10px rgba(255,45,149,.8)' }}
                />
              </div>
              <span className="font-display text-[9px] font-bold text-fuchsia-300">FAST</span>
            </div>
          </div>

          {/* center banner */}
          {banner && screen === 'playing' && (
            <div key={banner.id} className="absolute left-1/2 top-[30%] -translate-x-1/2 text-center">
              <div
                className={`anim-banner font-display text-3xl font-black tracking-widest sm:text-5xl ${banner.kind === 'gold' ? 'text-amber-300 text-glow-gold' : banner.kind === 'danger' ? 'text-rose-400' : 'text-white text-glow-cyan'}`}
              >
                {banner.text}
              </div>
              {banner.sub && <div className="anim-rise mt-2 text-sm font-semibold tracking-wide text-white/70">{banner.sub}</div>}
            </div>
          )}

          {/* mobile velocity mini */}
          <div className="absolute bottom-24 left-1/2 w-44 -translate-x-1/2 md:hidden">
            <div className="h-1 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full" style={{ width: `${Math.max(4, speedPct)}%`, background: 'linear-gradient(90deg,#22d3ee,#ff2d95)' }} />
            </div>
          </div>
        </div>
      )}

      {/* ================= touch controls ================= */}
      {isTouch && screen === 'playing' && (
        <div className="absolute inset-x-0 bottom-0 z-20 flex items-end justify-between p-4 pb-6" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)' }}>
          <button
            data-ui
            className="touch-btn neon-btn flex h-20 w-20 flex-col items-center justify-center rounded-2xl border border-fuchsia-400/40 bg-fuchsia-500/15 text-fuchsia-100 backdrop-blur-md active:bg-fuchsia-500/35"
            onPointerDown={(e) => { e.stopPropagation(); sound.unlock(); engineRef.current?.slidePress(); }}
            onPointerUp={(e) => { e.stopPropagation(); engineRef.current?.slideRelease(); }}
            onPointerCancel={() => engineRef.current?.slideRelease()}
            onPointerLeave={() => engineRef.current?.slideRelease()}
            aria-label="slide"
          >
            <ChevronDown className="h-7 w-7" />
            <span className="font-display text-[9px] font-bold tracking-widest">SLIDE</span>
          </button>
          <div className="pb-1 text-center text-[11px] font-semibold tracking-wide text-white/35">tap = jump · swipe ↓ = slide</div>
          <button
            data-ui
            className="touch-btn neon-btn flex h-20 w-20 flex-col items-center justify-center rounded-2xl border border-cyan-300/40 bg-cyan-400/15 text-cyan-100 backdrop-blur-md active:bg-cyan-400/35"
            onPointerDown={(e) => { e.stopPropagation(); sound.unlock(); engineRef.current?.jumpPress(); }}
            onPointerUp={(e) => { e.stopPropagation(); engineRef.current?.jumpRelease(); }}
            onPointerCancel={() => engineRef.current?.jumpRelease()}
            onPointerLeave={() => engineRef.current?.jumpRelease()}
            aria-label="jump"
          >
            <ChevronUp className="h-7 w-7" />
            <span className="font-display text-[9px] font-bold tracking-widest">JUMP</span>
          </button>
        </div>
      )}

      {/* ================= START ================= */}
      {screen === 'menu' && (
        <div className="absolute inset-0 z-30 flex items-center justify-center overflow-y-auto bg-gradient-to-b from-[#070714]/60 via-transparent to-[#070714]/85 p-4">
          <div className="w-full max-w-lg py-6">
            <div className="anim-pop text-center">
              <div className="inline-flex items-center gap-2 rounded-full border border-cyan-300/30 bg-cyan-400/10 px-4 py-1.5 backdrop-blur-md">
                <Zap className="h-3.5 w-3.5 text-cyan-300" />
                <span className="font-display text-[10px] font-bold tracking-[0.3em] text-cyan-200">SLOW → FAST · ENDLESS RUNNER</span>
              </div>
              <h1 className="anim-flicker title-gradient font-display mt-3 text-6xl font-black leading-none tracking-tight sm:text-7xl">NEON<br />RUSH</h1>
              <p className="mx-auto mt-3 max-w-sm text-[15px] font-medium leading-snug text-white/70">
                Start slow. End at <span className="font-bold text-fuchsia-300">lightspeed</span>. Jump the blocks, slide the drones, chain coins.
              </p>
            </div>

            <div className="anim-pop-d1 mt-5 flex items-center justify-center gap-3">
              {best > 0 && (
                <div className="flex items-center gap-2 rounded-full border border-amber-300/30 bg-amber-400/10 px-4 py-2">
                  <Crown className="h-4 w-4 text-amber-300" />
                  <span className="font-display tabular text-sm font-bold text-amber-200">{fmt(best)}</span>
                </div>
              )}
              <button onClick={startGame} data-ui className="btn-primary neon-btn anim-pulse-ring font-display flex items-center gap-3 rounded-2xl px-10 py-4 text-xl font-black tracking-widest text-white">
                <Play className="h-6 w-6 fill-white" /> PLAY
              </button>
              <button onClick={toggleMute} data-ui className="btn-ghost neon-btn flex h-12 w-12 items-center justify-center rounded-2xl text-white/70" aria-label="mute">
                {muted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
              </button>
            </div>
            <div className="anim-blink mt-2 text-center text-xs font-semibold tracking-widest text-white/40">PRESS SPACE / TAP TO START · 3 HEARTS</div>

            <div className="anim-pop-d2 neon-panel mt-5 grid grid-cols-2 gap-3 rounded-2xl p-4">
              <div className="rounded-xl bg-white/[0.04] p-3">
                <div className="flex items-center gap-1.5 text-cyan-300"><Keyboard className="h-4 w-4" /><span className="font-display text-[10px] font-bold tracking-widest">KEYBOARD</span></div>
                <div className="mt-2 space-y-1.5 text-[13px] font-semibold text-white/75">
                  <div className="flex items-center justify-between"><span>Jump / double-jump</span><Kbd>SPACE</Kbd></div>
                  <div className="flex items-center justify-between"><span>Slide / dive</span><Kbd>↓</Kbd></div>
                  <div className="flex items-center justify-between"><span>Pause</span><Kbd>P</Kbd></div>
                  <div className="flex items-center justify-between"><span>Jump (mouse)</span><Kbd>CLICK</Kbd></div>
                  <div className="text-[11px] text-white/45">hold SPACE = higher jump</div>
                </div>
              </div>
              <div className="rounded-xl bg-white/[0.04] p-3">
                <div className="flex items-center gap-1.5 text-fuchsia-300"><Hand className="h-4 w-4" /><span className="font-display text-[10px] font-bold tracking-widest">TOUCH</span></div>
                <div className="mt-2 space-y-1.5 text-[13px] font-semibold text-white/75">
                  <div className="flex items-center justify-between"><span>Jump</span><Kbd>TAP</Kbd></div>
                  <div className="flex items-center justify-between"><span>Slide</span><Kbd>SWIPE ↓</Kbd></div>
                  <div className="flex items-center justify-between"><span>Buttons</span><Kbd>◀ ▶</Kbd></div>
                  <div className="text-[11px] text-white/45">tap twice = double-jump</div>
                </div>
              </div>
            </div>

            <div className="anim-pop-d3 neon-panel mt-3 rounded-2xl p-4">
              <ScoreTable scores={scores} highlightId={null} compact />
            </div>
          </div>
        </div>
      )}

      {/* ================= PAUSE ================= */}
      {screen === 'paused' && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#050510]/70 p-4 backdrop-blur-sm">
          <div className="anim-pop neon-panel w-full max-w-sm rounded-3xl p-6 text-center">
            <div className="font-display text-[11px] tracking-[0.4em] text-cyan-300">TAKE A BREATHER</div>
            <h2 className="font-display mt-1 text-4xl font-black tracking-wider text-white text-glow-cyan">PAUSED</h2>
            <div className="mt-3 flex items-center justify-center gap-4 text-sm font-bold text-white/70">
              <span className="tabular">{fmt(hud.score)} pts</span>
              <span className="text-white/25">·</span>
              <span className="tabular">{hud.distance}m</span>
            </div>
            <div className="mt-5 space-y-2.5" data-ui>
              <button onClick={resumeGame} className="btn-primary neon-btn font-display flex w-full items-center justify-center gap-2 rounded-2xl px-6 py-3.5 text-base font-black tracking-widest text-white">
                <Play className="h-5 w-5 fill-white" /> RESUME
              </button>
              <div className="grid grid-cols-2 gap-2.5">
                <button onClick={retry} className="btn-ghost neon-btn font-display flex items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-bold tracking-widest text-white/85">
                  <RotateCcw className="h-4 w-4" /> RETRY
                </button>
                <button onClick={quitToMenu} className="btn-ghost neon-btn font-display flex items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-bold tracking-widest text-white/85">
                  <Home className="h-4 w-4" /> MENU
                </button>
              </div>
              <button onClick={toggleMute} className="btn-ghost neon-btn font-display flex w-full items-center justify-center gap-2 rounded-2xl px-4 py-2.5 text-xs font-bold tracking-widest text-white/60">
                {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />} {muted ? 'UNMUTE (M)' : 'MUTE (M)'}
              </button>
            </div>
            <div className="mt-4 text-[11px] font-semibold tracking-wide text-white/35">SPACE / CLICK jump · ↓ slide · hold for higher</div>
          </div>
        </div>
      )}

      {/* ================= GAME OVER ================= */}
      {screen === 'gameover' && result && (
        <div className="absolute inset-0 z-30 flex items-center justify-center overflow-y-auto bg-gradient-to-b from-[#1a0512]/70 via-[#070714]/60 to-[#070714]/90 p-4">
          <div className="w-full max-w-md py-4">
            <div className="anim-pop text-center">
              <div className="inline-flex items-center gap-2 rounded-full border border-rose-400/30 bg-rose-500/10 px-4 py-1.5">
                <Skull className="h-3.5 w-3.5 text-rose-300" />
                <span className="font-display text-[10px] font-bold tracking-[0.3em] text-rose-200">RUN TERMINATED</span>
              </div>
              <h2 className="font-display mt-2 text-5xl font-black tracking-wide text-white text-glow-pink sm:text-6xl">WRECKED</h2>
              {isBest ? (
                <div className="anim-pop-d1 mx-auto mt-2 inline-flex items-center gap-2 rounded-full border border-amber-300/50 bg-amber-400/15 px-5 py-1.5 shadow-[0_0_30px_rgba(251,191,36,0.4)]">
                  <Crown className="h-4 w-4 text-amber-300" />
                  <span className="font-display text-sm font-black tracking-[0.25em] text-amber-200 text-glow-gold">NEW BEST!</span>
                </div>
              ) : (
                <div className="mt-2 text-sm font-semibold text-white/50">best {fmt(best)} pts</div>
              )}
              <div className="font-display tabular mt-1 text-5xl font-black text-white">{fmt(result.score)}</div>
              <div className="text-xs font-bold tracking-[0.3em] text-white/40">POINTS</div>
            </div>

            <div className="anim-pop-d1 neon-panel mt-4 grid grid-cols-4 gap-2 rounded-2xl p-3 text-center">
              <Stat icon={<Wind className="h-4 w-4" />} label="DIST" value={`${result.distance}m`} />
              <Stat icon={<Coins className="h-4 w-4" />} label="COINS" value={`${result.coins}`} />
              <Stat icon={<Gauge className="h-4 w-4" />} label="TOP" value={`${result.topSpeed}`} sub="m/s" />
              <Stat icon={<Timer className="h-4 w-4" />} label="TIME" value={`${Math.floor(result.time)}s`} />
            </div>

            {canSave && !savedRef.current && (
              <div className="anim-pop-d2 neon-panel mt-3 rounded-2xl border-amber-300/30 p-4" data-ui>
                <div className="flex items-center gap-2 text-amber-200"><Medal className="h-4 w-4" /><span className="font-display text-xs font-bold tracking-widest">TOP-8 SCORE — TAG IT!</span></div>
                <div className="mt-2.5 flex gap-2">
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6))}
                    onKeyDown={(e) => { if (e.key === 'Enter' && result) { doSave(result, name); } e.stopPropagation(); }}
                    placeholder="ACE"
                    maxLength={6}
                    className="font-display min-w-0 flex-1 rounded-xl border border-white/15 bg-black/50 px-4 py-2.5 text-center text-lg font-black tracking-[0.3em] text-white outline-none placeholder:text-white/20 focus:border-amber-300/60"
                  />
                  <button onClick={() => result && doSave(result, name)} className="btn-primary neon-btn font-display shrink-0 rounded-xl px-5 py-2.5 text-sm font-black tracking-widest text-white">SAVE</button>
                </div>
              </div>
            )}

            <div className="anim-pop-d2 neon-panel mt-3 rounded-2xl p-4">
              <ScoreTable scores={scores} highlightId={savedId} compact={false} />
            </div>

            <div className="anim-pop-d3 mt-4 grid grid-cols-[1fr_auto] gap-2.5" data-ui>
              <button onClick={retry} className="btn-primary neon-btn anim-pulse-ring font-display flex items-center justify-center gap-2 rounded-2xl px-6 py-4 text-lg font-black tracking-widest text-white">
                <RotateCcw className="h-5 w-5" /> RETRY <span className="rounded-md bg-black/30 px-1.5 py-0.5 text-[10px]">R</span>
              </button>
              <button onClick={quitToMenu} className="btn-ghost neon-btn font-display flex items-center justify-center gap-2 rounded-2xl px-5 py-4 text-sm font-bold tracking-widest text-white/80">
                <Home className="h-4 w-4" /> MENU
              </button>
            </div>
            <div className="mt-2 text-center text-[11px] font-semibold tracking-widest text-white/35">INSTANT RESTART — SMASH R / ENTER / RETRY</div>
          </div>
        </div>
      )}
    </div>
  );
}

function Kbd({ children }: { children: React.ReactNode }) {
  return (
    <span className="font-display rounded-md border border-white/15 bg-black/50 px-1.5 py-0.5 text-[10px] font-bold tracking-wider text-cyan-100">
      {children}
    </span>
  );
}

function Stat({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-xl bg-white/[0.04] px-2 py-2.5">
      <div className="flex items-center justify-center gap-1 text-cyan-300/80">{icon}</div>
      <div className="font-display tabular mt-1 text-base font-extrabold text-white sm:text-lg">{value}{sub && <span className="ml-0.5 text-[10px] font-bold text-white/40">{sub}</span>}</div>
      <div className="font-display text-[9px] font-bold tracking-[0.25em] text-white/40">{label}</div>
    </div>
  );
}

function ScoreTable({ scores, highlightId, compact }: { scores: ScoreEntry[]; highlightId: string | null; compact: boolean }) {
  if (!scores.length) {
    return (
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 text-white/60">
          <Trophy className="h-4 w-4 text-amber-300/70" />
          <span className="font-display text-xs font-bold tracking-[0.25em]">LOCAL LEGENDS</span>
        </div>
        <div className="mt-2 text-sm font-medium text-white/40">No runs yet — be the first legend.</div>
      </div>
    );
  }
  const rows = compact ? scores.slice(0, 5) : scores;
  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2 text-white/70">
          <Trophy className="h-4 w-4 text-amber-300" />
          <span className="font-display text-xs font-bold tracking-[0.25em]">LOCAL LEGENDS</span>
        </div>
        <span className="text-[10px] font-bold tracking-widest text-white/30">THIS DEVICE</span>
      </div>
      <div className={`score-scroll space-y-1 ${rows.length > 5 ? 'max-h-44 overflow-y-auto pr-1' : ''}`}>
        {rows.map((s, i) => {
          const hot = highlightId === s.id;
          return (
            <div
              key={s.id}
              className={`flex items-center gap-2.5 rounded-xl px-2.5 py-1.5 text-sm ${hot ? 'border border-amber-300/50 bg-amber-400/15 shadow-[0_0_18px_rgba(251,191,36,0.25)]' : i === 0 ? 'border border-white/10 bg-white/[0.06]' : 'bg-white/[0.02]'}`}
            >
              <span className={`font-display w-6 text-center text-xs font-black ${i === 0 ? 'text-amber-300' : i === 1 ? 'text-slate-200' : i === 2 ? 'text-orange-300' : 'text-white/35'}`}>
                {i + 1}
              </span>
              <span className="font-display flex-1 truncate text-xs font-bold tracking-widest text-white/90">{s.name}</span>
              <span className="hidden text-[11px] font-semibold text-white/35 sm:inline">{s.distance}m · {s.coins}c</span>
              <span className="font-display tabular text-sm font-extrabold text-white">{fmt(s.score)}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
