import { sound } from './audio';

export type EngineMode = 'menu' | 'playing' | 'paused' | 'dying' | 'gameover';

export interface HudSnapshot {
  score: number;
  distance: number;
  coins: number;
  hearts: number;
  maxHearts: number;
  speedMps: number;
  speedNorm: number;
  combo: number;
  multiplier: number;
  best: number;
  time: number;
}

export interface GameResult {
  score: number;
  distance: number;
  coins: number;
  topSpeed: number;
  maxCombo: number;
  time: number;
}

export interface EngineEvents {
  onHud(h: HudSnapshot): void;
  onBanner(text: string, sub?: string, kind?: 'info' | 'gold' | 'danger'): void;
  onGameOver(r: GameResult): void;
  onDamage(hearts: number): void;
}

interface Obstacle { x: number; w: number; h: number; yOff: number; type: 'low' | 'wide' | 'tall' | 'fly'; passed: boolean; phase: number; }
interface Coin { x: number; y: number; taken: boolean; spin: number; vx: number; vy: number; mag: boolean; }
interface Particle { x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; color: string; grav: number; drag: number; shape: number; rot: number; vr: number; }
interface FloatText { x: number; y: number; text: string; life: number; max: number; color: string; size: number; }
interface TrailDot { x: number; y: number; w: number; h: number; life: number; slide: boolean; }
interface SpeedLine { x: number; y: number; len: number; spd: number; alpha: number; }
interface Star { x: number; y: number; r: number; tw: number; sp: number; }

const TAU = Math.PI * 2;
const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private ev: EngineEvents;
  private best = 0;

  mode: EngineMode = 'menu';

  private W = 0; private H = 0; private DPR = 1;
  private S = 1; // size scale from height
  private groundY = 0;
  private playerX = 120;
  private widthFactor = 1;
  private quality: 'high' | 'low' = 'high';

  private raf = 0;
  private lastT = 0;
  private elapsed = 0; // total wall time for bg anim
  private runTime = 0;
  private distancePx = 0;
  private score = 0;
  private coinScore = 0;
  private coins = 0;
  private combo = 0;
  private comboTimer = 0;
  private maxCombo = 0;
  private hearts = 3;
  private readonly maxHearts = 3;
  private speed = 0;
  private topSpeedPx = 0;
  private minSpeed = 360;
  private maxSpeed = 1180;

  // player physics (py = height above ground, vy up-positive)
  private py = 0; private vy = 0;
  private grounded = true;
  private coyote = 0; private buffer = 0;
  private jumps = 0;
  private sliding = false; private slideTimer = 0; private slideHeld = false;
  private jumpHeld = false;
  private invincible = 0;
  private runPhase = 0;
  private squash = 1; private squashV = 0;
  private flip = 0; private flipping = false;
  private landCooldown = 0;

  private obstacles: Obstacle[] = [];
  private coinsArr: Coin[] = [];
  private particles: Particle[] = [];
  private texts: FloatText[] = [];
  private trail: TrailDot[] = [];
  private speedLines: SpeedLine[] = [];
  private stars: Star[] = [];

  private trauma = 0;
  private flashA = 0; private flashColor = '255,45,149';
  private hitstop = 0;
  private slowmo = 0; private slowmoScale = 1;
  private dyingT = 0;
  private hudT = 0;
  private dustT = 0;
  private milestone = 250;
  private gapPx = 0;
  private scripted = 0;
  private fpsEMA = 60;
  private lowTimer = 0;

  // bg scroll offsets
  private offFar = 0; private offMid = 0; private offNear = 0; private offGrid = 0;
  private skyGrad: CanvasGradient | null = null;
  private floorGrad: CanvasGradient | null = null;
  private sunX = 0.72;
  private backTile: HTMLCanvasElement | null = null;
  private frontTile: HTMLCanvasElement | null = null;

  private destroyed = false;

  constructor(canvas: HTMLCanvasElement, events: EngineEvents, best: number) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('no 2d context');
    this.ctx = ctx;
    this.ev = events;
    this.best = best;
    this.resize();
    this.initStars();
    this.buildTiles();
    this.lastT = performance.now();
    const loop = (t: number) => {
      if (this.destroyed) return;
      this.frame(t);
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  setBest(b: number) { this.best = b; }

  resize = () => {
    const parent = this.canvas.parentElement;
    const w = parent ? parent.clientWidth : window.innerWidth;
    const h = parent ? parent.clientHeight : window.innerHeight;
    const isSmall = Math.min(w, h) < 620 || w < 700;
    this.DPR = Math.min(window.devicePixelRatio || 1, isSmall ? 1.8 : 2);
    this.quality = isSmall && this.DPR > 1.5 ? 'low' : 'high';
    this.W = Math.max(320, w); this.H = Math.max(420, h);
    this.canvas.width = Math.round(this.W * this.DPR);
    this.canvas.height = Math.round(this.H * this.DPR);
    this.canvas.style.width = `${this.W}px`;
    this.canvas.style.height = `${this.H}px`;
    this.S = clamp(this.H / 760, 0.72, 1.28);
    this.groundY = Math.round(this.H * (this.H < 560 ? 0.72 : 0.78));
    this.playerX = clamp(this.W * 0.22, 70, 260);
    this.widthFactor = clamp(this.W / 1100, 0.62, 1.18);
    this.minSpeed = 360; this.maxSpeed = 1180;
    // gradients
    const g = this.ctx.createLinearGradient(0, 0, 0, this.H);
    g.addColorStop(0, '#04040f');
    g.addColorStop(0.42, '#0b0b2a');
    g.addColorStop(0.68, '#1c0f3a');
    g.addColorStop(0.78, '#2b0f45');
    g.addColorStop(0.781, '#0a0a1e');
    g.addColorStop(1, '#050512');
    this.skyGrad = g;
    const fg = this.ctx.createLinearGradient(0, this.groundY, 0, this.H);
    fg.addColorStop(0, '#101032');
    fg.addColorStop(0.25, '#0a0a22');
    fg.addColorStop(1, '#04040e');
    this.floorGrad = fg;
    this.initStars();
    this.buildTiles();
    if (this.grounded) this.py = 0;
  };

  private initStars() {
    this.stars = [];
    const n = this.W < 600 ? 60 : 110;
    for (let i = 0; i < n; i++) {
      this.stars.push({ x: Math.random() * this.W, y: Math.random() * this.H * 0.6, r: rand(0.6, 2), tw: rand(0, TAU), sp: rand(0.2, 1) });
    }
  }

  private buildTiles() {
    // far city tile
    const mk = (w: number, h: number) => {
      const c = document.createElement('canvas');
      c.width = Math.max(2, Math.round(w)); c.height = Math.max(2, Math.round(h));
      return c;
    };
    const tileW = 1100;
    const backH = Math.round(this.H * 0.34);
    const bt = mk(tileW, backH);
    {
      const c = bt.getContext('2d'); if (c) {
        c.clearRect(0, 0, tileW, backH);
        let x = 0;
        let seed = 7;
        const sr = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
        while (x < tileW) {
          const bw = 40 + sr() * 90;
          const bh = backH * (0.3 + sr() * 0.65);
          const y = backH - bh;
          c.fillStyle = '#121236';
          c.fillRect(x, y, bw, bh);
          c.fillStyle = 'rgba(139,92,246,0.5)';
          c.fillRect(x, y, bw, 2);
          // windows
          c.fillStyle = 'rgba(34,211,238,0.28)';
          const cols = Math.floor(bw / 12), rows = Math.floor(bh / 16);
          for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
            if (sr() > 0.55) c.fillRect(x + 5 + i * 12, y + 8 + j * 16, 5, 7);
          }
          // antenna
          if (sr() > 0.7) { c.fillStyle = 'rgba(255,45,149,0.8)'; c.fillRect(x + bw / 2 - 1, y - 12, 2, 12); }
          x += bw + sr() * 26;
        }
      }
    }
    this.backTile = bt;
    const frontH = Math.round(this.H * 0.26);
    const ft = mk(tileW, frontH);
    {
      const c = ft.getContext('2d'); if (c) {
        c.clearRect(0, 0, tileW, frontH);
        let x = 0; let seed = 31;
        const sr = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
        while (x < tileW) {
          const bw = 60 + sr() * 110;
          const bh = frontH * (0.35 + sr() * 0.6);
          const y = frontH - bh;
          const grad = c.createLinearGradient(0, y, 0, frontH);
          grad.addColorStop(0, '#1a1a44'); grad.addColorStop(1, '#0a0a22');
          c.fillStyle = grad;
          c.fillRect(x, y, bw, bh);
          c.fillStyle = sr() > 0.5 ? 'rgba(255,45,149,0.75)' : 'rgba(34,211,238,0.75)';
          c.fillRect(x, y, bw, 2.5);
          c.fillStyle = 'rgba(251,191,36,0.35)';
          const cols = Math.floor(bw / 16), rows = Math.floor(bh / 20);
          for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
            if (sr() > 0.5) c.fillRect(x + 7 + i * 16, y + 10 + j * 20, 7, 9);
          }
          x += bw + sr() * 40;
        }
      }
    }
    this.frontTile = ft;
  }

  // ================= public controls =================

  start() {
    this.mode = 'playing';
    this.runTime = 0; this.distancePx = 0; this.score = 0; this.coinScore = 0;
    this.coins = 0; this.combo = 0; this.comboTimer = 0; this.maxCombo = 0;
    this.hearts = this.maxHearts;
    this.obstacles = []; this.coinsArr = []; this.particles = []; this.texts = [];
    this.trail = []; this.speedLines = [];
    this.py = 0; this.vy = 0; this.grounded = true; this.jumps = 0;
    this.coyote = 0; this.buffer = 0; this.sliding = false; this.slideTimer = 0;
    this.invincible = 0; this.flip = 0; this.flipping = false; this.squash = 1; this.squashV = 0;
    this.trauma = 0; this.flashA = 0; this.hitstop = 0; this.slowmo = 0;
    this.milestone = 250; this.scripted = 0;
    this.speed = this.minSpeed * this.widthFactor;
    this.topSpeedPx = this.speed;
    this.gapPx = 120;
    this.dustT = 0;
    sound.unlock(); sound.start(); sound.startMusic();
    this.ev.onBanner('GO!', 'hold JUMP for higher • slide under drones', 'info');
    this.pushHud(true);
  }

  pause() {
    if (this.mode !== 'playing') return;
    this.mode = 'paused';
  }
  resume() {
    if (this.mode !== 'paused') return;
    this.mode = 'playing';
    this.lastT = performance.now();
  }
  toMenu() {
    this.mode = 'menu';
    this.obstacles = []; this.coinsArr = [];
    this.trauma = 0; this.flashA = 0;
    sound.stopMusic();
    this.pushHud(true);
  }

  jumpPress() {
    sound.unlock();
    this.jumpHeld = true;
    if (this.mode !== 'playing') return;
    this.buffer = 0.16;
  }
  jumpRelease() {
    this.jumpHeld = false;
    if (this.mode !== 'playing') return;
    // variable jump height: cut upward velocity
    if (!this.grounded && this.vy > 340 * this.S) {
      this.vy *= 0.46;
    }
  }
  slidePress() {
    sound.unlock();
    this.slideHeld = true;
    if (this.mode !== 'playing') return;
    if (!this.grounded) {
      // fast fall
      this.vy = Math.min(this.vy, -200 * this.S);
    } else {
      this.beginSlide();
    }
  }
  slideRelease() {
    this.slideHeld = false;
    if (this.sliding) this.slideTimer = Math.min(this.slideTimer, 0.1);
  }

  private beginSlide() {
    if (this.sliding) { this.slideTimer = Math.max(this.slideTimer, 0.35); return; }
    this.sliding = true; this.slideTimer = 0.62;
    sound.slide();
    this.burst(this.playerX + 10, this.groundY - 6, 8, 'slide');
  }

  destroy() { this.destroyed = true; cancelAnimationFrame(this.raf); }

  // ================= frame =================

  private frame(now: number) {
    let dt = (now - this.lastT) / 1000;
    this.lastT = now;
    if (dt > 0.05) dt = 0.05;
    if (dt <= 0) { this.render(); return; }
    // fps tracking
    const fps = 1 / dt;
    this.fpsEMA += (fps - this.fpsEMA) * 0.05;
    if (this.fpsEMA < 42) { this.lowTimer += dt; if (this.lowTimer > 2) this.quality = 'low'; }
    else { this.lowTimer = 0; }

    if (this.mode === 'paused') { this.render(); return; }

    // hitstop / slowmo
    let scale = 1;
    if (this.hitstop > 0) { this.hitstop -= dt; scale = 0.05; }
    else if (this.slowmo > 0) { this.slowmo -= dt; scale = this.slowmoScale; }
    const sdt = dt * scale;
    this.elapsed += dt;

    if (this.mode === 'playing' || this.mode === 'dying' || this.mode === 'menu' || this.mode === 'gameover') {
      this.update(sdt, dt);
    }
    this.render();

    this.hudT -= dt;
    if (this.hudT <= 0 && (this.mode === 'playing' || this.mode === 'dying')) {
      this.hudT = 0.1;
      this.pushHud(false);
    }
  }

  private targetSpeed(): number {
    const t = this.mode === 'menu' ? 6 : this.runTime;
    const base = this.minSpeed + (this.maxSpeed - this.minSpeed) * (1 - Math.exp(-t / 24));
    return base * this.widthFactor;
  }

  private update(dt: number, rawDt: number) {
    const S = this.S;
    // speed
    if (this.mode === 'playing') {
      this.runTime += dt;
      this.speed += (this.targetSpeed() - this.speed) * Math.min(1, dt * 2.2);
      this.topSpeedPx = Math.max(this.topSpeedPx, this.speed);
      this.distancePx += this.speed * dt;
      const meters = this.meters();
      this.score = Math.floor(meters) + this.coinScore;
      if (meters >= this.milestone) {
        this.ev.onBanner(`${this.milestone}m — SPEED UP!`, 'faster • denser • deadlier', 'gold');
        sound.milestone();
        this.trauma = Math.min(1, this.trauma + 0.35);
        this.flash('251,191,36', 0.16);
        this.burst(this.playerX + 30, this.groundY - 120 * S, 22, 'gold');
        this.milestone += this.milestone < 1000 ? 250 : 500;
        this.pushHud(true);
      }
      // combo decay
      if (this.comboTimer > 0) {
        this.comboTimer -= dt;
        if (this.comboTimer <= 0) this.combo = 0;
      }
    } else if (this.mode === 'menu') {
      this.speed += ((this.minSpeed * 0.55 * this.widthFactor) - this.speed) * Math.min(1, dt * 1.5);
    } else if (this.mode === 'dying') {
      this.speed *= Math.max(0, 1 - dt * 2.4);
      this.dyingT -= rawDt;
      if (this.dyingT <= 0) {
        this.mode = 'gameover';
        sound.stopMusic();
        this.ev.onGameOver({
          score: this.score, distance: Math.floor(this.meters()), coins: this.coins,
          topSpeed: Math.round(this.topSpeedPx / (50 * S)), maxCombo: this.maxCombo, time: this.runTime,
        });
      }
    } else if (this.mode === 'gameover') {
      this.speed *= Math.max(0, 1 - dt * 1.2);
    }

    // bg scroll
    this.offFar += this.speed * dt * 0.12;
    this.offMid += this.speed * dt * 0.3;
    this.offNear += this.speed * dt * 0.55;
    this.offGrid += this.speed * dt;

    // ---- player ----
    if (this.mode === 'playing' || this.mode === 'dying') this.updatePlayer(dt);

    // ---- spawns ----
    if (this.mode === 'playing') {
      this.gapPx -= this.speed * dt;
      if (this.gapPx <= 0) { this.spawnNext(); }
      // move world
      for (const o of this.obstacles) o.x -= this.speed * dt;
      for (const c of this.coinsArr) {
        c.x -= this.speed * dt;
        c.spin += dt * 6;
        // magnet
        const px = this.playerX + 20 * S, pyScreen = this.groundY - this.py - 34 * S;
        const dx = px - c.x, dy = pyScreen - c.y;
        const d2 = dx * dx + dy * dy;
        const mr = 110 * S;
        if (!c.taken && d2 < mr * mr) {
          const d = Math.max(1, Math.sqrt(d2));
          const pull = 1400 * S * dt;
          c.x += (dx / d) * pull; c.y += (dy / d) * pull;
        }
        if (!c.taken && d2 < (34 * S) * (34 * S)) this.collectCoin(c);
      }
      // cull
      this.obstacles = this.obstacles.filter((o) => o.x + o.w > -80);
      this.coinsArr = this.coinsArr.filter((c) => !c.taken && c.x > -60);
      this.checkCollisions();
    } else {
      for (const o of this.obstacles) o.x -= this.speed * dt;
      for (const c of this.coinsArr) c.x -= this.speed * dt;
      this.obstacles = this.obstacles.filter((o) => o.x + o.w > -80);
    }

    // trail
    if ((this.mode === 'playing') && (Math.abs(this.vy) > 10 || !this.grounded || this.speed > 500 * this.widthFactor)) {
      const h = this.sliding ? 30 * S : 62 * S;
      this.trail.push({ x: this.playerX, y: this.groundY - this.py - h, w: 40 * S, h, life: 0.32, slide: this.sliding });
      if (this.trail.length > 14) this.trail.shift();
    }
    for (const t of this.trail) t.life -= dt;
    this.trail = this.trail.filter((t) => t.life > 0);

    // run dust
    if (this.mode === 'playing' && this.grounded && !this.sliding) {
      this.dustT -= dt;
      if (this.dustT <= 0) {
        this.dustT = clamp(0.11 - this.speedNorm() * 0.06, 0.04, 0.12);
        this.dust(this.playerX - 6, this.groundY - 2, 1);
      }
    }
    if (this.sliding && this.grounded && this.mode === 'playing') {
      if (Math.random() < 0.6) this.spark(this.playerX + rand(-10, 30) * S, this.groundY - 4, 1);
    }

    // speed lines
    const wantLines = this.mode === 'playing' ? Math.floor(this.speedNorm() * 14) : this.mode === 'menu' ? 2 : 0;
    if (this.speedLines.length < wantLines && Math.random() < 0.5) {
      this.speedLines.push({ x: this.W + 40, y: rand(0, this.H * 0.75), len: rand(60, 220), spd: rand(1400, 2400), alpha: rand(0.08, 0.3) });
    }
    for (const l of this.speedLines) l.x -= (l.spd + this.speed) * dt;
    this.speedLines = this.speedLines.filter((l) => l.x + l.len > -50);

    // particles
    for (const p of this.particles) {
      p.life -= dt;
      p.vy -= p.grav * dt;
      p.vx *= Math.max(0, 1 - p.drag * dt);
      p.vy *= Math.max(0, 1 - p.drag * 0.4 * dt);
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.rot += p.vr * dt;
    }
    this.particles = this.particles.filter((p) => p.life > 0);
    // texts
    for (const t of this.texts) { t.life -= dt; t.y -= 46 * dt; }
    this.texts = this.texts.filter((t) => t.life > 0);

    // shake / flash decay
    this.trauma = Math.max(0, this.trauma - rawDt * 1.6);
    this.flashA = Math.max(0, this.flashA - rawDt * 1.8);
    if (this.invincible > 0) this.invincible -= dt;
    if (this.landCooldown > 0) this.landCooldown -= dt;

    // squash spring
    const k = 180, d = 14;
    this.squashV += ((1 - this.squash) * k - this.squashV * d) * dt;
    this.squash += this.squashV * dt;
  }

  private speedNorm(): number {
    const lo = this.minSpeed * this.widthFactor, hi = this.maxSpeed * this.widthFactor;
    return clamp((this.speed - lo) / Math.max(1, hi - lo), 0, 1);
  }
  private meters(): number { return this.distancePx / (50 * this.S); }

  private updatePlayer(dt: number) {
    const S = this.S;
    const GRAV = 3400 * S;
    // buffered jump
    if (this.buffer > 0) {
      this.buffer -= dt;
      const canGround = this.grounded || this.coyote > 0;
      if (canGround) {
        this.doJump(false);
        this.buffer = 0;
      } else if (this.jumps < 2) {
        this.doJump(true);
        this.buffer = 0;
      }
    }
    if (this.coyote > 0) this.coyote -= dt;

    // slide timers
    if (this.sliding) {
      this.slideTimer -= dt;
      if (this.slideHeld && this.grounded) this.slideTimer = Math.max(this.slideTimer, 0.12);
      if (this.slideTimer <= 0) this.sliding = false;
    }

    // gravity (+ slide hold = heavier)
    let g = GRAV;
    if (!this.grounded && this.slideHeld) g *= 2.1;
    if (!this.grounded && !this.jumpHeld && this.vy > 0) g *= 1.5;
    this.vy -= g * dt;
    const maxFall = 1900 * S;
    if (this.vy < -maxFall) this.vy = -maxFall;

    const wasAir = !this.grounded;
    this.py += this.vy * dt;
    if (this.py <= 0) {
      this.py = 0;
      if (wasAir) {
        // landing!
        const hard = this.vy < -900 * S;
        this.grounded = true; this.vy = 0; this.jumps = 0; this.flipping = false; this.flip = 0;
        this.coyote = 0;
        this.squash = hard ? 0.68 : 0.8;
        this.squashV = 0;
        if (this.mode === 'playing') {
          this.burst(this.playerX + 20 * S, this.groundY - 2, hard ? 12 : 6, 'dust');
          if (hard) { this.trauma = Math.min(1, this.trauma + 0.14); sound.land(); }
          if (this.slideHeld) this.beginSlide();
        }
      } else {
        this.vy = 0;
      }
    } else {
      if (this.grounded) { this.grounded = false; this.coyote = 0.12; this.squash = 1.18; }
    }

    this.runPhase += dt * (8 + this.speedNorm() * 14);
    if (this.flipping) {
      this.flip += dt * 11;
      if (this.flip >= TAU) { this.flip = 0; this.flipping = false; }
    }
  }

  private doJump(isDouble: boolean) {
    const S = this.S;
    if (!isDouble) {
      this.vy = 1180 * S;
      this.grounded = false; this.jumps = 1; this.coyote = 0;
      this.sliding = false; this.slideTimer = 0;
      this.squash = 1.24;
      sound.jump();
      this.burst(this.playerX + 18 * S, this.groundY - this.py - 4, 8, 'dust');
    } else {
      this.vy = 1040 * S;
      this.jumps = 2; this.flipping = true; this.flip = 0;
      sound.doubleJump();
      this.ring(this.playerX + 20 * S, this.groundY - this.py - 30 * S);
    }
  }

  // ================= spawning =================

  private spawnNext() {
    const S = this.S;
    // scripted tutorial first
    if (this.scripted < 4) {
      const i = this.scripted++;
      if (i === 0) {
        this.addObstacle('low', this.W + 120);
        this.coinArc(this.W + 120, 7);
        this.gapPx = this.speed * 0.85;
      } else if (i === 1) {
        this.coinLine(this.W + 100, this.groundY - 120 * S, 6);
        this.gapPx = this.speed * 0.7;
      } else if (i === 2) {
        this.addObstacle('low', this.W + 160);
        this.coinArc(this.W + 160, 7);
        this.gapPx = this.speed * 0.8;
      } else {
        this.addObstacle('fly', this.W + 200);
        this.coinSlideLine(this.W + 200);
        this.ev.onBanner('SLIDE!', 'press ↓ / SWIPE DOWN / SLIDE button', 'info');
        this.gapPx = this.speed * 0.9;
      }
      return;
    }
    const t = this.runTime;
    const diff = clamp(t / 75, 0, 1);
    const roll = Math.random();
    let type: Obstacle['type'];
    if (t < 14) type = roll < 0.7 ? 'low' : 'wide';
    else if (t < 30) type = roll < 0.45 ? 'low' : roll < 0.7 ? 'wide' : roll < 0.9 ? 'fly' : 'tall';
    else type = roll < 0.3 ? 'low' : roll < 0.5 ? 'wide' : roll < 0.68 ? 'fly' : roll < 0.85 ? 'tall' : 'wide';

    const x = this.W + rand(40, 160);
    if (type === 'fly') {
      this.addObstacle('fly', x);
      if (Math.random() < 0.75) this.coinSlideLine(x);
    } else {
      this.addObstacle(type, x);
      if (Math.random() < 0.7) this.coinArc(x, 6 + Math.floor(Math.random() * 3));
      // doubles at higher difficulty
      if (diff > 0.35 && Math.random() < 0.3 + diff * 0.3) {
        const gap = rand(150, 230) * S;
        this.addObstacle(Math.random() < 0.6 ? 'low' : 'wide', x + 90 * S + gap);
      }
    }
    // coin bonus lines sometimes instead
    if (Math.random() < 0.16) {
      this.coinLine(x + 200, this.groundY - rand(90, 200) * S, 5);
    }
    const timeGap = rand(0.62 - diff * 0.18, 1.0 - diff * 0.25);
    this.gapPx = Math.max(300 * S, this.speed * timeGap);
  }

  private addObstacle(type: Obstacle['type'], x: number) {
    const S = this.S;
    let w = 34 * S, h = 60 * S, yOff = 0;
    if (type === 'wide') { w = 86 * S; h = 56 * S; }
    if (type === 'tall') { w = 38 * S; h = 118 * S; }
    if (type === 'fly') { w = 60 * S; h = 42 * S; yOff = 52 * S; }
    this.obstacles.push({ x, w, h, yOff, type, passed: false, phase: rand(0, TAU) });
  }

  private coinArc(centerX: number, n: number) {
    const S = this.S;
    const width = 200 * S, height = 120 * S;
    for (let i = 0; i < n; i++) {
      const t = n === 1 ? 0.5 : i / (n - 1);
      this.coinsArr.push({
        x: centerX + 10 * S + (t - 0.5) * width,
        y: this.groundY - 34 * S - Math.sin(t * Math.PI) * height,
        taken: false, spin: rand(0, TAU), vx: 0, vy: 0, mag: false,
      });
    }
  }
  private coinLine(x: number, y: number, n: number) {
    const S = this.S;
    for (let i = 0; i < n; i++) this.coinsArr.push({ x: x + i * 38 * S, y, taken: false, spin: rand(0, TAU), vx: 0, vy: 0, mag: false });
  }
  private coinSlideLine(x: number) {
    const S = this.S;
    for (let i = 0; i < 5; i++) this.coinsArr.push({ x: x - 30 * S + i * 38 * S, y: this.groundY - 26 * S, taken: false, spin: rand(0, TAU), vx: 0, vy: 0, mag: false });
  }

  // ================= collisions / coins / damage =================

  private playerBox(): { x: number; y: number; w: number; h: number } {
    const S = this.S;
    const h = this.sliding ? 30 * S : 60 * S;
    const w = this.sliding ? 52 * S : 34 * S;
    return { x: this.playerX + (this.sliding ? -6 * S : 3 * S), y: this.groundY - this.py - h, w, h };
  }

  private checkCollisions() {
    const S = this.S;
    const pb = this.playerBox();
    for (const o of this.obstacles) {
      const shrink = 7 * S;
      const oy = o.type === 'fly' ? this.groundY - o.yOff - o.h + Math.sin(this.elapsed * 3 + o.phase) * 5 * S : this.groundY - o.h;
      const ox = o.x + shrink, ow = o.w - shrink * 2;
      const oy2 = oy + shrink * 0.6, oh = o.h - shrink;
      const hit = pb.x < ox + ow && pb.x + pb.w > ox && pb.y < oy2 + oh && pb.y + pb.h > oy2;
      if (hit) {
        if (this.invincible <= 0 && this.mode === 'playing') this.damage(o.x + o.w / 2, oy2 + oh / 2);
      } else if (!o.passed && o.x + o.w < pb.x) {
        o.passed = true;
        // near miss?
        let gap = Infinity;
        if (o.type === 'fly') {
          const playerTop = pb.y;
          gap = oy2 + oh - playerTop; // obstacle bottom minus player top? must be small positive overlapwise
          // actually clearance = playerTop - obstacleBottom (player below) — small means close
          gap = playerTop - (oy2 + oh);
          if (!this.sliding) gap = Infinity; // jumped into gap? no bonus
        } else {
          const playerBottom = pb.y + pb.h;
          gap = oy2 - playerBottom; // obstacle top minus player bottom (player above) — small = close
        }
        if (gap > -12 * S && gap < 34 * S) {
          const bonus = Math.round(25 * this.multiplier());
          this.coinScore += bonus;
          this.score = Math.floor(this.meters()) + this.coinScore;
          this.texts.push({ x: this.playerX + 40 * S, y: this.groundY - this.py - 110 * S, text: `NEAR MISS +${bonus}`, life: 0.9, max: 0.9, color: '#22d3ee', size: 17 });
          sound.nearMiss();
          this.trauma = Math.min(1, this.trauma + 0.12);
          this.hitstop = Math.max(this.hitstop, 0.035);
          this.burst(this.playerX + 30 * S, this.groundY - this.py - 40 * S, 6, 'cyan');
        }
      }
    }
  }

  private multiplier(): number { return 1 + Math.min(this.combo / 8, 4); }

  private collectCoin(c: Coin) {
    c.taken = true;
    this.coins++;
    this.combo++; this.maxCombo = Math.max(this.maxCombo, this.combo);
    this.comboTimer = 2.2;
    const m = this.multiplier();
    const val = Math.round(10 * m);
    this.coinScore += val;
    this.score = Math.floor(this.meters()) + this.coinScore;
    sound.coin(this.combo);
    this.texts.push({ x: c.x, y: c.y - 14, text: `+${val}`, life: 0.6, max: 0.6, color: '#fbbf24', size: 15 });
    this.burst(c.x, c.y, 7, 'gold');
    if (this.combo > 0 && this.combo % 15 === 0) {
      this.ev.onBanner(`COMBO x${Math.floor(m)}`, `${this.combo} coins chained!`, 'gold');
    }
  }

  private damage(hx: number, hy: number) {
    this.hearts--;
    this.invincible = 1.5;
    this.combo = 0;
    this.trauma = 1;
    this.hitstop = 0.11;
    this.slowmo = 0.45; this.slowmoScale = 0.35;
    this.flash('255,45,80', 0.34);
    sound.hit();
    this.burst(hx, hy, 26, 'hit');
    this.ring(hx, hy);
    this.texts.push({ x: this.playerX + 30, y: this.groundY - this.py - 130 * this.S, text: this.hearts > 0 ? 'OUCH!' : 'WRECKED!', life: 1, max: 1, color: '#ff2d5e', size: 24 });
    this.ev.onDamage(this.hearts);
    this.pushHud(true);
    if (this.hearts <= 0) {
      this.mode = 'dying';
      this.dyingT = 1.05;
      this.slowmo = 0.9; this.slowmoScale = 0.25;
      this.trauma = 1;
      sound.gameOver();
      this.burst(this.playerX + 20, this.groundY - this.py - 40, 46, 'hit');
      this.burst(this.playerX + 20, this.groundY - this.py - 40, 20, 'gold');
    }
  }

  // ================= particles =================

  private push(p: Particle) {
    const cap = this.quality === 'low' ? 150 : 280;
    if (this.particles.length >= cap) this.particles.shift();
    this.particles.push(p);
  }
  private burst(x: number, y: number, n: number, kind: 'dust' | 'gold' | 'cyan' | 'hit' | 'slide') {
    for (let i = 0; i < n; i++) {
      const a = rand(0, TAU);
      let sp = rand(60, 320) * this.S, color = '#a5b4fc', grav = 900 * this.S, size = rand(2, 5), life = rand(0.3, 0.7);
      if (kind === 'dust') { color = Math.random() < 0.5 ? '#8b7ff0' : '#4c4c86'; sp = rand(40, 220) * this.S; grav = 500 * this.S; }
      if (kind === 'gold') { color = Math.random() < 0.6 ? '#fbbf24' : '#fde68a'; sp = rand(80, 380) * this.S; grav = 700 * this.S; size = rand(2, 6); }
      if (kind === 'cyan') { color = Math.random() < 0.5 ? '#22d3ee' : '#a5f3fc'; sp = rand(120, 420) * this.S; grav = 200 * this.S; }
      if (kind === 'hit') { color = ['#ff2d5e', '#ff2d95', '#fbbf24', '#ffffff'][Math.floor(Math.random() * 4)]; sp = rand(150, 650) * this.S; grav = 1100 * this.S; size = rand(3, 8); life = rand(0.4, 1); }
      if (kind === 'slide') { color = Math.random() < 0.5 ? '#fbbf24' : '#22d3ee'; sp = rand(100, 400) * this.S; grav = 300 * this.S; }
      this.push({
        x: x + rand(-8, 8), y: y + rand(-6, 6),
        vx: Math.cos(a) * sp - this.speed * 0.25, vy: Math.abs(Math.sin(a)) * sp * 0.9 + 60,
        life, max: life, size: size * this.S, color, grav, drag: 1.6, shape: Math.random() < 0.3 ? 1 : 0, rot: rand(0, TAU), vr: rand(-8, 8),
      });
    }
  }
  private dust(x: number, y: number, n: number) { this.burst(x, y, n * 2, 'dust'); }
  private spark(x: number, y: number, n: number) { this.burst(x, y, n * 3, 'slide'); }
  private ring(x: number, y: number) {
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * TAU;
      this.push({ x, y, vx: Math.cos(a) * 320 * this.S, vy: Math.sin(a) * 320 * this.S + 100, life: 0.45, max: 0.45, size: 3.5 * this.S, color: '#22d3ee', grav: 0, drag: 2.2, shape: 0, rot: 0, vr: 0 });
    }
  }
  private flash(rgb: string, a: number) { this.flashColor = rgb; this.flashA = Math.max(this.flashA, a); }

  private pushHud(force: boolean) {
    void force;
    this.ev.onHud({
      score: this.score, distance: Math.floor(this.meters()), coins: this.coins,
      hearts: Math.max(0, this.hearts), maxHearts: this.maxHearts,
      speedMps: Math.round(this.speed / (50 * this.S)), speedNorm: this.speedNorm(),
      combo: this.combo, multiplier: this.multiplier(), best: this.best, time: this.runTime,
    });
  }

  // ================= render =================

  private render() {
    const { ctx, W, H } = this;
    ctx.setTransform(this.DPR, 0, 0, this.DPR, 0, 0);
    // shake
    const sh = this.trauma * this.trauma;
    const shx = sh * 22 * (Math.random() * 2 - 1);
    const shy = sh * 16 * (Math.random() * 2 - 1);
    ctx.save();
    ctx.translate(shx, shy);

    // sky
    ctx.fillStyle = this.skyGrad ?? '#070714';
    ctx.fillRect(-30, -30, W + 60, H + 60);

    this.drawStars(ctx);
    this.drawSun(ctx);
    this.drawCities(ctx);
    this.drawFloor(ctx);
    this.drawCoins(ctx);
    this.drawObstacles(ctx);
    if (this.mode !== 'menu') this.drawTrail(ctx);
    this.drawPlayer(ctx);
    this.drawParticles(ctx);
    this.drawSpeedLines(ctx);
    this.drawTexts(ctx);

    ctx.restore();

    // flash
    if (this.flashA > 0.004) {
      ctx.fillStyle = `rgba(${this.flashColor},${this.flashA.toFixed(3)})`;
      ctx.fillRect(0, 0, W, H);
    }
    // low-hp pulse
    if (this.mode === 'playing' && this.hearts === 1) {
      const p = (Math.sin(this.elapsed * 6) * 0.5 + 0.5) * 0.16;
      const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.36, W / 2, H / 2, Math.max(W, H) * 0.72);
      g.addColorStop(0, 'rgba(255,45,90,0)');
      g.addColorStop(1, `rgba(255,45,90,${p.toFixed(3)})`);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    }
    // speed vignette at high velocity
    if (this.mode === 'playing' && this.speedNorm() > 0.5) {
      const a = (this.speedNorm() - 0.5) * 0.24;
      const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.42, W / 2, H / 2, Math.max(W, H) * 0.75);
      g.addColorStop(0, 'rgba(0,0,0,0)');
      g.addColorStop(1, `rgba(10,4,30,${a.toFixed(3)})`);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    }
  }

  private drawStars(ctx: CanvasRenderingContext2D) {
    ctx.save();
    for (const s of this.stars) {
      const x = (((s.x - this.offFar * s.sp * 0.2) % this.W) + this.W) % this.W;
      const a = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(this.elapsed * 2 + s.tw));
      ctx.globalAlpha = a * 0.9;
      ctx.fillStyle = '#cfe9ff';
      ctx.fillRect(x, s.y, s.r, s.r);
    }
    ctx.restore();
  }

  private drawSun(ctx: CanvasRenderingContext2D) {
    const S = this.S;
    const r = Math.min(this.W, this.H) * 0.16;
    const x = this.W * this.sunX, y = this.H * 0.52;
    ctx.save();
    const glow = ctx.createRadialGradient(x, y, r * 0.2, x, y, r * 2.4);
    glow.addColorStop(0, 'rgba(255,45,149,0.35)');
    glow.addColorStop(1, 'rgba(255,45,149,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(x - r * 2.6, y - r * 2.6, r * 5.2, r * 5.2);
    // striped sun
    ctx.beginPath();
    ctx.arc(x, y, r, 0, TAU);
    ctx.clip();
    const sg = ctx.createLinearGradient(0, y - r, 0, y + r);
    sg.addColorStop(0, '#fde68a'); sg.addColorStop(0.45, '#fb923c'); sg.addColorStop(0.75, '#ff2d95'); sg.addColorStop(1, '#8b5cf6');
    ctx.fillStyle = sg;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
    ctx.fillStyle = 'rgba(7,7,20,0.85)';
    let sy = y + r * 0.1;
    let th = r * 0.06;
    while (sy < y + r) { ctx.fillRect(x - r, sy, r * 2, th); sy += th + r * 0.13; th *= 1.35; }
    ctx.restore();
    void S;
  }

  private drawCities(ctx: CanvasRenderingContext2D) {
    const horizon = this.groundY;
    // far tile
    if (this.backTile) {
      const th = this.backTile.height, tw = this.backTile.width;
      const y = horizon - th - 6;
      let off = -(this.offMid % tw);
      for (let x = off - tw; x < this.W + tw; x += tw) ctx.drawImage(this.backTile, x, y);
    }
    if (this.frontTile) {
      const th = this.frontTile.height, tw = this.frontTile.width;
      const y = horizon - th + 4;
      let off = -(this.offNear % tw);
      for (let x = off - tw; x < this.W + tw; x += tw) ctx.drawImage(this.frontTile, x, y);
    }
  }

  private drawFloor(ctx: CanvasRenderingContext2D) {
    const { W, H } = this;
    const gy = this.groundY;
    ctx.fillStyle = this.floorGrad ?? '#0a0a22';
    ctx.fillRect(-30, gy, W + 60, H - gy + 30);
    // perspective grid
    ctx.save();
    ctx.strokeStyle = 'rgba(139,92,246,0.22)';
    ctx.lineWidth = 1;
    const rows = 5;
    for (let i = 1; i <= rows; i++) {
      const t = i / rows;
      const y = gy + Math.pow(t, 1.7) * (H - gy);
      ctx.globalAlpha = 0.1 + t * 0.25;
      ctx.beginPath(); ctx.moveTo(-30, y); ctx.lineTo(W + 30, y); ctx.stroke();
    }
    ctx.globalAlpha = 1;
    // moving verticals
    ctx.strokeStyle = 'rgba(34,211,238,0.16)';
    const gap = 90;
    let off = -(this.offGrid % gap);
    for (let x = off - gap; x < W + gap; x += gap) {
      ctx.beginPath(); ctx.moveTo(x, gy); ctx.lineTo(x - 26, H); ctx.stroke();
    }
    ctx.restore();
    // neon ground line
    const pulse = 0.75 + 0.25 * Math.sin(this.elapsed * 3);
    ctx.save();
    if (this.quality === 'high') { ctx.shadowColor = '#22d3ee'; ctx.shadowBlur = 18; }
    ctx.strokeStyle = `rgba(34,211,238,${0.65 + 0.3 * pulse})`;
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(-30, gy + 0.5); ctx.lineTo(W + 30, gy + 0.5); ctx.stroke();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(-30, gy + 0.5); ctx.lineTo(W + 30, gy + 0.5); ctx.stroke();
    // magenta underglow
    ctx.strokeStyle = 'rgba(255,45,149,0.35)';
    ctx.lineWidth = 6;
    ctx.beginPath(); ctx.moveTo(-30, gy + 6); ctx.lineTo(W + 30, gy + 6); ctx.stroke();
    ctx.restore();
  }

  private drawCoins(ctx: CanvasRenderingContext2D) {
    const S = this.S;
    ctx.save();
    for (const c of this.coinsArr) {
      if (c.x < -30 || c.x > this.W + 30) continue;
      const sq = Math.abs(Math.cos(c.spin));
      const r = 10 * S;
      if (this.quality === 'high') { ctx.shadowColor = '#fbbf24'; ctx.shadowBlur = 14; }
      ctx.fillStyle = '#3a2a08';
      ctx.beginPath(); ctx.ellipse(c.x, c.y, r + 2, r + 2, 0, 0, TAU); ctx.fill();
      ctx.shadowBlur = 0;
      const g = ctx.createLinearGradient(c.x - r, c.y - r, c.x + r, c.y + r);
      g.addColorStop(0, '#fef3c7'); g.addColorStop(0.5, '#fbbf24'); g.addColorStop(1, '#b45309');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.ellipse(c.x, c.y, Math.max(2.5, r * (0.25 + 0.75 * sq)), r, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.beginPath(); ctx.ellipse(c.x - r * 0.25, c.y - r * 0.3, r * 0.22 * sq + 0.6, r * 0.2, -0.5, 0, TAU); ctx.fill();
    }
    ctx.restore();
  }

  private drawObstacles(ctx: CanvasRenderingContext2D) {
    const S = this.S;
    for (const o of this.obstacles) {
      if (o.x + o.w < -40 || o.x > this.W + 120) continue;
      const isFly = o.type === 'fly';
      const bob = isFly ? Math.sin(this.elapsed * 3 + o.phase) * 5 * S : 0;
      const y = isFly ? this.groundY - o.yOff - o.h + bob : this.groundY - o.h;
      ctx.save();
      if (this.quality === 'high') { ctx.shadowColor = isFly ? '#22d3ee' : '#ff2d95'; ctx.shadowBlur = 16; }
      // body
      const bg = ctx.createLinearGradient(0, y, 0, y + o.h);
      if (isFly) { bg.addColorStop(0, '#0e3a4a'); bg.addColorStop(1, '#0a1626'); }
      else { bg.addColorStop(0, '#2a1030'); bg.addColorStop(1, '#120a24'); }
      ctx.fillStyle = bg;
      this.rr(ctx, o.x, y, o.w, o.h, isFly ? 12 * S : 6 * S);
      ctx.fill();
      ctx.shadowBlur = 0;
      // border
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = isFly ? '#22d3ee' : '#ff2d95';
      this.rr(ctx, o.x + 1, y + 1, o.w - 2, o.h - 2, isFly ? 11 * S : 5 * S);
      ctx.stroke();
      if (!isFly) {
        // hazard stripes near top
        ctx.save();
        this.rr(ctx, o.x + 1, y + 1, o.w - 2, o.h - 2, 5 * S);
        ctx.clip();
        ctx.fillStyle = 'rgba(255,45,149,0.16)';
        const sh = 12 * S;
        for (let sx = o.x - o.h; sx < o.x + o.w + o.h; sx += 22 * S) {
          ctx.beginPath();
          ctx.moveTo(sx, y); ctx.lineTo(sx + sh, y); ctx.lineTo(sx + sh - 10 * S, y + 18 * S); ctx.lineTo(sx - 10 * S, y + 18 * S);
          ctx.closePath(); ctx.fill();
        }
        // bright cap
        ctx.fillStyle = '#ff2d95';
        ctx.fillRect(o.x, y, o.w, 4 * S);
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        ctx.fillRect(o.x, y, o.w, 1.5 * S);
        // spikes
        ctx.fillStyle = '#ff2d95';
        const n = Math.max(2, Math.floor(o.w / (18 * S)));
        for (let i = 0; i < n; i++) {
          const sx = o.x + (i + 0.5) * (o.w / n);
          ctx.beginPath();
          ctx.moveTo(sx - 7 * S, y); ctx.lineTo(sx + 7 * S, y); ctx.lineTo(sx, y - 10 * S);
          ctx.closePath(); ctx.fill();
        }
        ctx.restore();
      } else {
        // drone eye
        const cx = o.x + o.w / 2, cy = y + o.h / 2;
        ctx.fillStyle = '#ff2d5e';
        ctx.beginPath(); ctx.arc(cx, cy, 9 * S, 0, TAU); ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.arc(cx - 2 * S, cy - 2 * S, 3 * S, 0, TAU); ctx.fill();
        // rotor
        ctx.strokeStyle = 'rgba(165,243,252,0.8)';
        ctx.lineWidth = 2;
        const rw = (14 + 6 * Math.sin(this.elapsed * 40 + o.phase)) * S;
        ctx.beginPath(); ctx.moveTo(cx - rw, y - 4 * S); ctx.lineTo(cx + rw, y - 4 * S); ctx.stroke();
        // thruster glow
        ctx.fillStyle = 'rgba(34,211,238,0.5)';
        ctx.fillRect(o.x + 6 * S, y + o.h - 2, o.w - 12 * S, 3 * S);
        // danger chevrons below
        ctx.fillStyle = 'rgba(34,211,238,0.9)';
        ctx.font = `700 ${Math.round(11 * S)}px Orbitron, sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText('▼ ▼ ▼', cx, y + o.h + 14 * S);
      }
      ctx.restore();
    }
  }

  private drawTrail(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (const t of this.trail) {
      const a = (t.life / 0.32) * 0.28;
      ctx.fillStyle = t.slide ? `rgba(255,45,149,${a.toFixed(3)})` : `rgba(34,211,238,${a.toFixed(3)})`;
      this.rr(ctx, t.x - 6, t.y, t.w, t.h, 10);
      ctx.fill();
    }
    ctx.restore();
  }

  private drawPlayer(ctx: CanvasRenderingContext2D) {
    const S = this.S;
    if (this.mode === 'menu') { this.drawMenuRunner(ctx); return; }
    if (this.mode === 'gameover') return; // exploded
    const dying = this.mode === 'dying';
    // blink while invincible
    if (this.invincible > 0 && !dying && Math.floor(this.elapsed * 14) % 2 === 0) ctx.globalAlpha = 0.35;

    const cx = this.playerX + 20 * S;
    const feetY = this.groundY - this.py;
    const squashY = this.squash;
    const squashX = 1 / Math.sqrt(Math.max(0.4, squashY));

    ctx.save();
    ctx.translate(cx, feetY);
    if (this.flipping) ctx.rotate(this.flip * 0.9);
    ctx.scale(squashX, squashY);
    if (this.quality === 'high') { ctx.shadowColor = '#22d3ee'; ctx.shadowBlur = 20; }

    const lean = 0.14 + this.speedNorm() * 0.22;
    if (this.sliding) {
      // ---- slide pose: low streamlined dash ----
      ctx.rotate(-0.08);
      // body
      const bg = ctx.createLinearGradient(0, -34 * S, 0, 0);
      bg.addColorStop(0, '#67e8f9'); bg.addColorStop(1, '#0e7490');
      ctx.fillStyle = bg;
      this.rr(ctx, -30 * S, -30 * S, 62 * S, 24 * S, 12 * S);
      ctx.fill();
      ctx.shadowBlur = 0;
      // visor
      ctx.fillStyle = '#ff2d95';
      this.rr(ctx, 12 * S, -27 * S, 16 * S, 9 * S, 4 * S);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.fillRect(14 * S, -25.5 * S, 12 * S, 2 * S);
      // legs forward
      ctx.strokeStyle = '#164e63';
      ctx.lineWidth = 9 * S; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(-24 * S, -12 * S); ctx.lineTo(26 * S, -6 * S); ctx.stroke();
      ctx.strokeStyle = '#22d3ee';
      ctx.lineWidth = 5 * S;
      ctx.beginPath(); ctx.moveTo(-24 * S, -12 * S); ctx.lineTo(26 * S, -6 * S); ctx.stroke();
      // scarf
      this.drawScarf(ctx, -28 * S, -24 * S, true);
    } else {
      ctx.rotate(lean * 0.4);
      const air = !this.grounded;
      const run = Math.sin(this.runPhase);
      const run2 = Math.sin(this.runPhase + Math.PI);
      // legs
      ctx.lineCap = 'round';
      const hipY = -34 * S;
      if (!air) {
        // back leg
        ctx.strokeStyle = '#0e3a4e'; ctx.lineWidth = 11 * S;
        ctx.beginPath(); ctx.moveTo(-2 * S, hipY); ctx.lineTo(-2 * S + run * 15 * S, -2 * S + Math.max(0, -run2) * -6 * S); ctx.stroke();
        ctx.strokeStyle = '#22d3ee'; ctx.lineWidth = 6 * S;
        ctx.beginPath(); ctx.moveTo(-2 * S, hipY); ctx.lineTo(-2 * S + run * 15 * S, -3 * S); ctx.stroke();
        // front leg
        ctx.strokeStyle = '#0e3a4e'; ctx.lineWidth = 11 * S;
        ctx.beginPath(); ctx.moveTo(2 * S, hipY); ctx.lineTo(2 * S + run2 * 15 * S, -2 * S); ctx.stroke();
        ctx.strokeStyle = '#67e8f9'; ctx.lineWidth = 6 * S;
        ctx.beginPath(); ctx.moveTo(2 * S, hipY); ctx.lineTo(2 * S + run2 * 15 * S, -3 * S); ctx.stroke();
      } else {
        // tucked in air
        ctx.strokeStyle = '#0e3a4e'; ctx.lineWidth = 11 * S;
        ctx.beginPath(); ctx.moveTo(0, hipY); ctx.lineTo(14 * S, -12 * S); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, hipY); ctx.lineTo(-10 * S, -16 * S); ctx.stroke();
        ctx.strokeStyle = '#22d3ee'; ctx.lineWidth = 6 * S;
        ctx.beginPath(); ctx.moveTo(0, hipY); ctx.lineTo(14 * S, -12 * S); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, hipY); ctx.lineTo(-10 * S, -16 * S); ctx.stroke();
      }
      // torso
      const tg = ctx.createLinearGradient(0, -72 * S, 0, -30 * S);
      tg.addColorStop(0, '#a5f3fc'); tg.addColorStop(0.55, '#22d3ee'); tg.addColorStop(1, '#0e7490');
      ctx.fillStyle = tg;
      this.rr(ctx, -11 * S, -70 * S, 24 * S, 40 * S, 10 * S);
      ctx.fill();
      ctx.shadowBlur = 0;
      // chest core
      ctx.fillStyle = '#ff2d95';
      ctx.beginPath(); ctx.arc(3 * S, -52 * S, 5 * S + Math.sin(this.elapsed * 8) * 1 * S, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      ctx.beginPath(); ctx.arc(3 * S, -52 * S, 2 * S, 0, TAU); ctx.fill();
      // arms
      ctx.strokeStyle = '#164e63'; ctx.lineWidth = 9 * S;
      if (!air) {
        ctx.beginPath(); ctx.moveTo(0, -62 * S); ctx.lineTo(run2 * 12 * S, -44 * S); ctx.stroke();
      } else {
        ctx.beginPath(); ctx.moveTo(0, -62 * S); ctx.lineTo(16 * S, -50 * S); ctx.stroke();
      }
      // head
      ctx.fillStyle = '#e0f2fe';
      ctx.beginPath(); ctx.arc(6 * S, -82 * S, 13 * S, 0, TAU); ctx.fill();
      // visor
      ctx.fillStyle = '#0b0b24';
      this.rr(ctx, 0 * S, -89 * S, 20 * S, 11 * S, 5 * S);
      ctx.fill();
      ctx.fillStyle = '#ff2d95';
      this.rr(ctx, 2 * S, -87 * S, 16 * S, 7 * S, 3.5 * S);
      ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      ctx.fillRect(4 * S, -85.5 * S, 12 * S, 2 * S);
      this.drawScarf(ctx, -8 * S, -76 * S, false);
      if (this.quality === 'high') { ctx.shadowColor = '#22d3ee'; ctx.shadowBlur = 20; }
    }
    ctx.restore();
    ctx.globalAlpha = 1;

    // ground reflection
    if (this.py < 200 * S) {
      ctx.save();
      ctx.globalAlpha = clamp(0.22 - this.py / (900 * S), 0, 0.22);
      ctx.translate(cx, this.groundY + 4);
      ctx.scale(1, -0.5);
      ctx.translate(-cx, -(this.groundY - this.py - 40 * S));
      ctx.fillStyle = '#22d3ee';
      this.rr(ctx, cx - 16 * S, this.groundY - this.py - 70 * S, 34 * S, this.sliding ? 26 * S : 64 * S, 10 * S);
      ctx.fill();
      ctx.restore();
    }
  }

  private drawScarf(ctx: CanvasRenderingContext2D, x: number, y: number, slide: boolean) {
    const S = this.S;
    const w1 = (26 + this.speedNorm() * 30) * S;
    const wave = Math.sin(this.elapsed * (10 + this.speedNorm() * 10)) * 8 * S;
    const wave2 = Math.cos(this.elapsed * 13) * 6 * S;
    ctx.save();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = '#ff2d95';
    ctx.lineCap = 'round';
    ctx.lineWidth = (slide ? 7 : 8) * S;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.bezierCurveTo(x - w1 * 0.4, y + wave * 0.4, x - w1 * 0.7, y + wave, x - w1, y + wave2);
    ctx.stroke();
    ctx.strokeStyle = '#f9a8d4';
    ctx.lineWidth = 2.5 * S;
    ctx.beginPath();
    ctx.moveTo(x, y - 1);
    ctx.bezierCurveTo(x - w1 * 0.4, y + wave * 0.4 - 1, x - w1 * 0.7, y + wave - 1, x - w1, y + wave2 - 1);
    ctx.stroke();
    ctx.restore();
  }

  private drawMenuRunner(ctx: CanvasRenderingContext2D) {
    // idle attract-mode runner: bob in place on the left third
    const S = this.S;
    const cx = this.playerX + 20 * S;
    const bob = Math.sin(this.elapsed * 4) * 4 * S;
    const feetY = this.groundY - Math.abs(Math.sin(this.elapsed * 6)) * 6 * S;
    this.runPhase += 0.12;
    ctx.save();
    ctx.translate(cx, feetY + bob * 0.3);
    if (this.quality === 'high') { ctx.shadowColor = '#22d3ee'; ctx.shadowBlur = 20; }
    const run = Math.sin(this.elapsed * 10);
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#0e3a4e'; ctx.lineWidth = 11 * S;
    ctx.beginPath(); ctx.moveTo(0, -34 * S); ctx.lineTo(run * 14 * S, 0); ctx.stroke();
    ctx.strokeStyle = '#22d3ee'; ctx.lineWidth = 6 * S;
    ctx.beginPath(); ctx.moveTo(0, -34 * S); ctx.lineTo(run * 14 * S, -2 * S); ctx.stroke();
    const tg = ctx.createLinearGradient(0, -72 * S, 0, -30 * S);
    tg.addColorStop(0, '#a5f3fc'); tg.addColorStop(1, '#0e7490');
    ctx.fillStyle = tg;
    this.rr(ctx, -11 * S, -70 * S, 24 * S, 40 * S, 10 * S);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#ff2d95';
    ctx.beginPath(); ctx.arc(3 * S, -52 * S, 5 * S, 0, TAU); ctx.fill();
    ctx.fillStyle = '#e0f2fe';
    ctx.beginPath(); ctx.arc(6 * S, -82 * S, 13 * S, 0, TAU); ctx.fill();
    ctx.fillStyle = '#0b0b24';
    this.rr(ctx, 0, -89 * S, 20 * S, 11 * S, 5 * S); ctx.fill();
    ctx.fillStyle = '#ff2d95';
    this.rr(ctx, 2 * S, -87 * S, 16 * S, 7 * S, 3.5 * S); ctx.fill();
    this.drawScarf(ctx, -8 * S, -76 * S, false);
    ctx.restore();
    void bob;
  }

  private drawParticles(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (const p of this.particles) {
      const t = clamp(p.life / p.max, 0, 1);
      ctx.globalAlpha = t;
      ctx.fillStyle = p.color;
      if (p.shape === 1) {
        ctx.save();
        ctx.translate(p.x, p.y); ctx.rotate(p.rot);
        ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
        ctx.restore();
      } else {
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (0.4 + 0.6 * t), 0, TAU); ctx.fill();
      }
    }
    ctx.restore();
  }

  private drawSpeedLines(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    for (const l of this.speedLines) {
      ctx.globalAlpha = l.alpha;
      ctx.strokeStyle = '#a5f3fc';
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(l.x, l.y); ctx.lineTo(l.x + l.len, l.y); ctx.stroke();
    }
    ctx.restore();
  }

  private drawTexts(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.textAlign = 'center';
    for (const t of this.texts) {
      const k = clamp(t.life / t.max, 0, 1);
      ctx.globalAlpha = Math.min(1, k * 2);
      if (this.quality === 'high') { ctx.shadowColor = t.color; ctx.shadowBlur = 12; }
      ctx.fillStyle = t.color;
      ctx.font = `800 ${Math.round(t.size * this.S + 4)}px Orbitron, sans-serif`;
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.restore();
  }

  private rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
    const rr = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + rr, y);
    ctx.arcTo(x + w, y, x + w, y + h, rr);
    ctx.arcTo(x + w, y + h, x, y + h, rr);
    ctx.arcTo(x, y + h, x, y, rr);
    ctx.arcTo(x, y, x + w, y, rr);
    ctx.closePath();
  }
}
