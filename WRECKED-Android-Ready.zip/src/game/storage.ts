export interface ScoreEntry {
  id: string;
  name: string;
  score: number;
  distance: number;
  coins: number;
  topSpeed: number;
  date: number;
}

const KEY = 'neon-rush-highscores-v1';
const NAME_KEY = 'neon-rush-player-name';
const MAX = 8;

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as ScoreEntry[];
    if (!Array.isArray(arr)) return [];
    return arr
      .filter((s) => typeof s?.score === 'number')
      .sort((a, b) => b.score - a.score)
      .slice(0, MAX);
  } catch {
    return [];
  }
}

export function qualifies(score: number): boolean {
  if (score <= 0) return false;
  const list = loadScores();
  if (list.length < MAX) return true;
  return score > list[list.length - 1].score;
}

export function saveScore(entry: Omit<ScoreEntry, 'id' | 'date'>): ScoreEntry[] {
  const full: ScoreEntry = {
    ...entry,
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    date: Date.now(),
  };
  const list = [...loadScores(), full].sort((a, b) => b.score - a.score).slice(0, MAX);
  try { localStorage.setItem(KEY, JSON.stringify(list)); } catch { /* noop */ }
  return list;
}

export function bestScore(): number {
  const list = loadScores();
  return list.length ? list[0].score : 0;
}

export function lastName(): string {
  try { return localStorage.getItem(NAME_KEY) || 'ACE'; } catch { return 'ACE'; }
}
export function saveName(n: string) {
  try { localStorage.setItem(NAME_KEY, n.toUpperCase().slice(0, 6) || 'ACE'); } catch { /* noop */ }
}
