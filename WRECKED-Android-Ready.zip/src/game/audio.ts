// Procedural WebAudio SFX + tiny synthwave music loop. No assets needed.

export class SoundManager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private musicTimer: number | null = null;
  private step = 0;
  private nextTime = 0;
  muted = false;
  musicOn = false;

  constructor() {
    try {
      this.muted = localStorage.getItem('neon-rush-muted') === '1';
    } catch { /* noop */ }
  }

  /** Must be called from a user gesture at least once. */
  unlock() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 1;
      this.master.connect(this.ctx.destination);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = 0.9;
      this.sfxGain.connect(this.master);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.34;
      this.musicGain.connect(this.master);

      // white noise buffer for hats / explosions
      const len = this.ctx.sampleRate * 1;
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    } catch {
      this.ctx = null;
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
    try { localStorage.setItem('neon-rush-muted', m ? '1' : '0'); } catch { /* noop */ }
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 1, this.ctx.currentTime, 0.02);
    }
  }

  private tone(opts: {
    freq: number; freqEnd?: number; dur: number; type?: OscillatorType;
    vol?: number; delay?: number; curve?: 'exp' | 'lin';
  }) {
    if (!this.ctx || !this.sfxGain) return;
    const t0 = this.ctx.currentTime + (opts.delay ?? 0);
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = opts.type ?? 'square';
    osc.frequency.setValueAtTime(Math.max(20, opts.freq), t0);
    if (opts.freqEnd) osc.frequency.exponentialRampToValueAtTime(Math.max(20, opts.freqEnd), t0 + opts.dur);
    const v = opts.vol ?? 0.2;
    g.gain.setValueAtTime(v, t0);
    if (opts.curve === 'lin') g.gain.linearRampToValueAtTime(0.0001, t0 + opts.dur);
    else g.gain.exponentialRampToValueAtTime(0.0001, t0 + opts.dur);
    osc.connect(g); g.connect(this.sfxGain);
    osc.start(t0); osc.stop(t0 + opts.dur + 0.02);
  }

  private noise(opts: { dur: number; vol?: number; delay?: number; filterFreq?: number; type?: BiquadFilterType }) {
    if (!this.ctx || !this.sfxGain || !this.noiseBuf) return;
    const t0 = this.ctx.currentTime + (opts.delay ?? 0);
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = this.ctx.createBiquadFilter();
    f.type = opts.type ?? 'highpass';
    f.frequency.value = opts.filterFreq ?? 1200;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(opts.vol ?? 0.2, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + opts.dur);
    src.connect(f); f.connect(g); g.connect(this.sfxGain);
    src.start(t0); src.stop(t0 + opts.dur + 0.02);
  }

  uiClick() { this.tone({ freq: 660, freqEnd: 880, dur: 0.08, type: 'square', vol: 0.12 }); }
  start() {
    this.tone({ freq: 220, freqEnd: 440, dur: 0.12, type: 'sawtooth', vol: 0.16 });
    this.tone({ freq: 440, freqEnd: 880, dur: 0.16, type: 'square', vol: 0.14, delay: 0.09 });
  }
  jump() { this.tone({ freq: 280, freqEnd: 640, dur: 0.16, type: 'square', vol: 0.16 }); }
  doubleJump() {
    this.tone({ freq: 420, freqEnd: 920, dur: 0.16, type: 'square', vol: 0.16 });
    this.noise({ dur: 0.12, vol: 0.06, filterFreq: 3000 });
  }
  slide() { this.noise({ dur: 0.22, vol: 0.14, filterFreq: 900, type: 'bandpass' }); }
  land() { this.noise({ dur: 0.09, vol: 0.1, filterFreq: 500, type: 'lowpass' }); }
  coin(combo = 0) {
    const base = 880 * Math.pow(2, Math.min(combo, 12) / 24);
    this.tone({ freq: base, dur: 0.09, type: 'sine', vol: 0.2 });
    this.tone({ freq: base * 1.5, dur: 0.14, type: 'sine', vol: 0.18, delay: 0.06 });
  }
  nearMiss() {
    this.tone({ freq: 1200, freqEnd: 2400, dur: 0.12, type: 'sawtooth', vol: 0.1 });
    this.noise({ dur: 0.14, vol: 0.08, filterFreq: 4000 });
  }
  hit() {
    this.noise({ dur: 0.35, vol: 0.35, filterFreq: 700, type: 'lowpass' });
    this.tone({ freq: 220, freqEnd: 40, dur: 0.4, type: 'sawtooth', vol: 0.28 });
  }
  milestone() {
    [523, 659, 784, 1046].forEach((f, i) =>
      this.tone({ freq: f, dur: 0.16, type: 'square', vol: 0.12, delay: i * 0.07 }));
  }
  gameOver() {
    [440, 349, 293, 220, 146].forEach((f, i) =>
      this.tone({ freq: f, freqEnd: f * 0.94, dur: 0.24, type: 'sawtooth', vol: 0.14, delay: i * 0.13 }));
    this.noise({ dur: 0.7, vol: 0.2, filterFreq: 400, type: 'lowpass', delay: 0.1 });
  }
  newBest() {
    [784, 988, 1175, 1568, 2093].forEach((f, i) =>
      this.tone({ freq: f, dur: 0.2, type: 'triangle', vol: 0.16, delay: i * 0.08 }));
  }

  // ---------- tiny synthwave sequencer ----------
  startMusic() {
    if (!this.ctx || this.musicTimer !== null) return;
    this.musicOn = true;
    this.step = 0;
    this.nextTime = this.ctx.currentTime + 0.06;
    const tick = () => {
      if (!this.ctx || !this.musicGain) return;
      const bpm = 116;
      const spb = 60 / bpm / 2; // 8th notes
      while (this.nextTime < this.ctx.currentTime + 0.25) {
        this.scheduleStep(this.step, this.nextTime);
        this.nextTime += spb;
        this.step = (this.step + 1) % 64;
      }
    };
    this.musicTimer = window.setInterval(tick, 90);
  }

  stopMusic() {
    this.musicOn = false;
    if (this.musicTimer !== null) { clearInterval(this.musicTimer); this.musicTimer = null; }
  }

  private scheduleStep(step: number, t: number) {
    if (!this.ctx || !this.musicGain || !this.noiseBuf) return;
    // bassline: A minor groove
    const bassNotes = [55, 55, 65.4, 55, 82.4, 55, 73.4, 65.4]; // A1 C2 E2 D2...
    const bar = Math.floor(step / 8) % 8;
    const sub = step % 8;
    const dt = t - this.ctx.currentTime;
    if (sub % 2 === 0) {
      const f = bassNotes[bar] * (sub === 6 ? 2 : 1);
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      const flt = this.ctx.createBiquadFilter();
      osc.type = 'sawtooth';
      osc.frequency.value = f;
      flt.type = 'lowpass';
      flt.frequency.value = 420;
      g.gain.setValueAtTime(0.0, t);
      g.gain.linearRampToValueAtTime(0.5, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
      osc.connect(flt); flt.connect(g); g.connect(this.musicGain);
      osc.start(t); osc.stop(t + 0.26);
      void dt;
    }
    // hats on offbeats
    if (sub % 2 === 1) {
      const src = this.ctx.createBufferSource();
      src.buffer = this.noiseBuf; src.loop = true;
      const f = this.ctx.createBiquadFilter();
      f.type = 'highpass'; f.frequency.value = 7000;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.12, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.06);
      src.connect(f); f.connect(g); g.connect(this.musicGain);
      src.start(t); src.stop(t + 0.08);
    }
    // sparkle arp every 2 bars
    if (step % 16 === 14) {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.value = 440 * Math.pow(2, [0, 3, 7, 12][(step >> 4) % 4] / 12);
      g.gain.setValueAtTime(0.08, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
      osc.connect(g); g.connect(this.musicGain);
      osc.start(t); osc.stop(t + 0.45);
    }
  }
}

export const sound = new SoundManager();
